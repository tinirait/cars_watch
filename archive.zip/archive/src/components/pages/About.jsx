function About() {
    return (
        <div className="p-4">
            <h1 className="text-2xl font-bold">About Us</h1>
            <p className="mt-2">We help you buy cars from the US via online auctions.</p>
        </div>
    );
}

export default About;
